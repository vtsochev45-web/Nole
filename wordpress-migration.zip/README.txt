WordPress Migration Package
===========================

Files included:
  wordpress-export.xml  – Import via WordPress Admin > Tools > Import > WordPress
  _site/                – Pre-built HTML pages (can be used as static reference)

Import steps:
  1. In your WordPress admin panel go to Tools > Import.
  2. Choose 'WordPress' and click 'Install Now' if prompted.
  3. Click 'Run Importer', upload wordpress-export.xml and click 'Upload file and import'.
  4. Assign imported posts to an existing user (or create one).
  5. Click 'Submit'.

Source site: https://vtsochev45-web.github.io/Nole
Generated:   2026-02-28 20:10 UTC
