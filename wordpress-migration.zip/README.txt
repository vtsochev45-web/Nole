WordPress Migration Package
===========================

Files included:
  wordpress-export.xml  – Import via WordPress Admin > Tools > Import > WordPress
  wordpress-theme/      – Custom WordPress theme matching the original site design
  _site/                – Pre-built HTML pages (can be used as static reference)

Theme installation steps:
  1. Copy the wordpress-theme/ folder to wp-content/themes/ on your server.
  2. Rename the folder to 'uk-farm-blog'.
  3. In Appearance > Themes, activate 'UK Farm Blog'.
  4. In Appearance > Menus, create a menu and assign it to Primary Menu.

Content import steps:
  1. In your WordPress admin panel go to Tools > Import.
  2. Choose 'WordPress' and click 'Install Now' if prompted.
  3. Click 'Run Importer', upload wordpress-export.xml and click 'Upload file and import'.
  4. Assign imported posts to an existing user (or create one).
  5. Click 'Submit'.

Source site: https://vtsochev45-web.github.io/Nole
Generated:   2026-03-01 04:54 UTC
